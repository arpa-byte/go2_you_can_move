from launch import LaunchDescription

from launch.actions import DeclareLaunchArgument

from launch.substitutions import LaunchConfiguration

from launch_ros.actions import Node, ComposableNodeContainer

from launch_ros.descriptions import ComposableNode

from ament_index_python.packages import get_package_share_directory

import os
 
def get_user_coordinates():
    """Interactive CLI to get target coordinates from user."""
    print("\n" + "="*60)
    print("         GO2 COORDINATE NAVIGATOR - SETUP")
    print("="*60)
    
    # Get target X coordinate
    while True:
        try:
            target_x_input = input("\nEnter target X coordinate (meters) [default: 1.0]: ").strip()
            target_x = float(target_x_input) if target_x_input else 1.0
            break
        except ValueError:
            print("Invalid input. Please enter a valid number.")
    
    # Get target Y coordinate
    while True:
        try:
            target_y_input = input("Enter target Y coordinate (meters) [default: 1.0]: ").strip()
            target_y = float(target_y_input) if target_y_input else 1.0
            break
        except ValueError:
            print("Invalid input. Please enter a valid number.")
    
    # Get target Yaw (orientation)
    while True:
        try:
            target_yaw_input = input("Enter target Yaw/orientation (radians) [default: 0.0]: ").strip()
            target_yaw = float(target_yaw_input) if target_yaw_input else 0.0
            break
        except ValueError:
            print("Invalid input. Please enter a valid number.")
    
    print("\n" + "="*60)
    print(f"Target Goal Set:")
    print(f"  X: {target_x:.2f} m")
    print(f"  Y: {target_y:.2f} m")
    print(f"  Yaw: {target_yaw:.4f} rad ({target_yaw * 180 / 3.14159:.1f}°)")
    print("="*60 + "\n")
    
    return str(target_x), str(target_y), str(target_yaw)

def generate_launch_description():

    # --- Get user input for coordinates ---
    target_x, target_y, target_yaw = get_user_coordinates()

    # --- Config Files ---

    nav_params_file = os.path.join(

        get_package_share_directory('go2_behavior'),

        'config',

        'navigate_params.yaml'

    )

    rviz_config_file = os.path.join(

        get_package_share_directory('go2_behavior'),

        'rviz',

        'navigate.rviz'

    )
 
    # --- Launch arguments (now using user input) ---

    declare_target_x = DeclareLaunchArgument(

        'target_x',

        default_value=target_x,

        description='Target X coordinate for the coordinate_navigator'

    )

    declare_target_y = DeclareLaunchArgument(

        'target_y',

        default_value=target_y,

        description='Target Y coordinate for the coordinate_navigator'

    )

    declare_target_yaw = DeclareLaunchArgument(

        'target_yaw',

        default_value=target_yaw,

        description='Target yaw (radians) for the coordinate_navigator'

    )
 
    target_x_config = LaunchConfiguration('target_x')

    target_y_config = LaunchConfiguration('target_y')

    target_yaw_config = LaunchConfiguration('target_yaw')
 
    # --- Node 1: The Go2 Driver (REMAPPED/SILENCED) ---

    # We define this explicitly so we can remap its /tf and /odom topics.

    # This prevents it from fighting with our custom odometry bridge.

    driver_node = ComposableNode(

        package='go2_driver',

        plugin='go2_driver::Go2Driver',

        name='go2_driver',

        namespace='',

        remappings=[

            ('/tf', '/tf_driver_ignored'),       # Silence driver TF

            ('/odom', '/odom_driver_ignored'),   # Silence driver Odom

        ]

    )
 
    # Container for the driver (required structure for go2_driver)

    driver_container = ComposableNodeContainer(

        name='go2_container',

        namespace='',

        package='rclcpp_components',

        executable='component_container',

        composable_node_descriptions=[driver_node],

        output='screen',

    )
 
    # --- Node 2: Pointcloud to Laserscan (Standard) ---

    # This was in the original driver launch, we keep it.

    pointcloud_node = Node(

        package='pointcloud_to_laserscan',

        executable='pointcloud_to_laserscan_node',

        name='pointcloud_to_laserscan',

        namespace='',

        output='screen',

        remappings=[('/cloud_in', '/pointcloud')],

        parameters=[{

            'target_frame': 'radar',

            'transform_tolerance': 0.01,

        }],

    )
 
    # --- Node 3: Odometry Bridge (Our "Truth" Source) ---

    # This provides the clean /odom and /tf that we actually want to use.

    odometry_bridge_node = Node(

        package='go2_odometry_bridge',

        executable='go2_odom_bridge_node',

        name='go2_odometry_bridge_node',

        output='screen'

    )
 
    # --- Node 4: Coordinate Navigator (The Brain) ---

    # Accept the target coordinates from launch arguments and pass as parameters.

    navigate_node = Node(

        package='go2_behavior',

        executable='coordinate_navigator',

        name='coordinate_navigator_node',

        output='screen',

        parameters=[

            nav_params_file,

            {

                'target_x': target_x_config,

                'target_y': target_y_config,

                'target_yaw': target_yaw_config,

            }

        ],

        prefix='gnome-terminal --' # Pop-out terminal for keyboard input if desired

    )
 
    # --- Node 5: RViz ---

    rviz_node = Node(

        package='rviz2',

        executable='rviz2',

        name='rviz2',

        arguments=['-d', rviz_config_file],

        output='screen'

    )
 
    return LaunchDescription([

        declare_target_x,

        declare_target_y,

        declare_target_yaw,

        driver_container,

        pointcloud_node,

        odometry_bridge_node,

        navigate_node,

        rviz_node

    ])